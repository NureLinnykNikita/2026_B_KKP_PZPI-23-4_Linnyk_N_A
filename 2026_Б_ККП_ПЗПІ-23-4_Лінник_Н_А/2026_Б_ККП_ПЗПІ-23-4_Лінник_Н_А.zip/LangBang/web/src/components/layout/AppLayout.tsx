import { Outlet, Navigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Sidebar } from './Sidebar';
import { useAuthStore } from '../../store/auth.store';
import { setLanguage } from '../../i18n';
import { Icons } from '../ui/icons';

function LangSwitcher() {
  const { i18n } = useTranslation();
  const lang = i18n.language.startsWith('uk') ? 'uk' : 'en';

  return (
    <button
      onClick={() => setLanguage(lang === 'uk' ? 'en' : 'uk')}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: 30,
        padding: '0 12px',
        borderRadius: 'var(--lb-radius-pill)',
        background: 'var(--lb-panel-soft)',
        border: '1px solid var(--lb-line)',
        color: 'var(--lb-text-muted)',
        fontSize: 12,
        fontWeight: 600,
        fontFamily: 'var(--lb-font-sans)',
        cursor: 'pointer',
        transition: 'var(--lb-trans)',
        letterSpacing: '0.04em',
      }}
    >
      <Icons.Globe size={14} stroke="currentColor" />
      {lang === 'uk' ? 'UK' : 'EN'}
    </button>
  );
}

export function AppLayout() {
  const { isAuthenticated, user } = useAuthStore();

  if (!isAuthenticated) return <Navigate to="/auth/login" replace />;
  if (isAuthenticated && user && !user.nativeLanguageId) {
    return <Navigate to="/onboarding" replace />;
  }

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <header
          style={{
            height: 48,
            flexShrink: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',
            padding: '0 28px',
            borderBottom: '1px solid var(--lb-line)',
            background: 'var(--lb-bg)',
          }}
        >
          <LangSwitcher />
        </header>
        <main
          style={{
            flex: 1,
            overflow: 'auto',
            padding: '32px 28px',
            background: 'var(--lb-bg)',
          }}
        >
          <Outlet />
        </main>
      </div>
    </div>
  );
}

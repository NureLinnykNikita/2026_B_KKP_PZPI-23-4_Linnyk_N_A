import { Outlet, Navigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuthStore } from '../../store/auth.store';
import { setLanguage } from '../../i18n';
import { Icons } from '../ui/icons';

function LangSwitcher() {
  const { i18n } = useTranslation();
  const lang = i18n.language.startsWith('uk') ? 'uk' : 'en';

  return (
    <button
      onClick={() => setLanguage(lang === 'uk' ? 'en' : 'uk')}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: 30,
        padding: '0 12px',
        borderRadius: 'var(--lb-radius-pill)',
        background: 'var(--lb-panel-soft)',
        border: '1px solid var(--lb-line)',
        color: 'var(--lb-text-muted)',
        fontSize: 12,
        fontWeight: 600,
        fontFamily: 'var(--lb-font-sans)',
        cursor: 'pointer',
        transition: 'var(--lb-trans)',
        letterSpacing: '0.04em',
      }}
    >
      <Icons.Globe size={14} stroke="currentColor" />
      {lang === 'uk' ? 'UK' : 'EN'}
    </button>
  );
}

export function AuthLayout() {
  const { t } = useTranslation();
  const { isAuthenticated } = useAuthStore();
  if (isAuthenticated) return <Navigate to="/app/home" replace />;

  return (
    <div
      style={{
        position: 'relative',
        minHeight: '100vh',
        background: 'var(--lb-bg)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
      }}
    >
      <div style={{ position: 'absolute', top: 16, right: 24 }}>
        <LangSwitcher />
      </div>
      <div style={{ width: '100%', maxWidth: 420 }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{ fontFamily: 'var(--lb-font-display)', fontSize: 28, fontWeight: 600, color: 'var(--lb-accent)', letterSpacing: '-0.02em' }}>
            LangBang
          </div>
          <div style={{ fontSize: 13, color: 'var(--lb-text-muted)', marginTop: 6 }}>
            {t('auth.tagline')}
          </div>
        </div>
        <Outlet />
      </div>
    </div>
  );
}

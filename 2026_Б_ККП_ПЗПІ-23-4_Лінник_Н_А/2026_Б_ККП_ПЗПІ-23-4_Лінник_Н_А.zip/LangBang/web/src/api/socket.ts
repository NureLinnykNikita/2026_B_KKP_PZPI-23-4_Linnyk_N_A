import { io, type Socket } from 'socket.io-client';
import { BASE_URL, getAccessToken } from './client';
import type { Conversation, Message } from '../types';

export type ServerToClientEvents = {
  'message:new': (payload: { conversationId: string; message: Message }) => void;
  'conversation:updated': (payload: { conversation: Conversation }) => void;
};

type ClientToServerEvents = {
  'conversation:join': (conversationId: string) => void;
};

let socket: Socket<ServerToClientEvents, ClientToServerEvents> | null = null;

function getSocketUrl() {
  return BASE_URL.replace(/\/api\/?$/, '');
}

export function getChatSocket() {
  const token = getAccessToken();

  if (!token) {
    return null;
  }

  if (!socket) {
    socket = io(getSocketUrl(), {
      autoConnect: false,
      withCredentials: true,
      auth: { token },
    });
  }

  socket.auth = { token };

  if (!socket.connected) {
    socket.connect();
  }

  return socket;
}

export function disconnectChatSocket() {
  socket?.disconnect();
  socket = null;
}

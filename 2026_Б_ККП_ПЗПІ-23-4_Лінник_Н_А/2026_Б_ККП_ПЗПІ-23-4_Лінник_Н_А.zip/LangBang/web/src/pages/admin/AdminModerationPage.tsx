import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { adminApi } from '../../api/endpoints';
import { Button, Card, Input, Spinner } from '../../components/ui';
import { Icons } from '../../components/ui/icons';
import { formatDate } from '../../i18n/locale';
import type { AdminModerationMessage } from '../../types';

const PAGE_SIZE = 20;

function conversationLabel(message: AdminModerationMessage) {
  if (message.conversation.title) return message.conversation.title;

  const usernames = message.conversation.participants
    .map(participant => participant.user?.username)
    .filter(Boolean);

  return usernames.length > 0 ? usernames.join(', ') : 'Direct conversation';
}

export function AdminModerationPage() {
  const { t, i18n } = useTranslation();
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['admin/moderation/messages', search, page],
    queryFn: () =>
      adminApi
        .getModerationMessages({
          search: search || undefined,
          page,
          limit: PAGE_SIZE,
        })
        .then(r => r.data),
  });

  const deleteMessage = useMutation({
    mutationFn: (messageId: string) => adminApi.deleteModerationMessage(messageId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin/moderation/messages'] });
      setConfirmDelete(null);
    },
  });

  const totalPages = data ? Math.max(Math.ceil(data.total / PAGE_SIZE), 1) : 1;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--lb-section-gap)', animation: 'fadeIn 0.2s ease' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 16, flexWrap: 'wrap' }}>
        <div>
          <h1 className="lb-h1" style={{ marginBottom: 6 }}>{t('admin.moderation')}</h1>
          <p style={{ margin: 0, color: 'var(--lb-text-muted)', fontSize: 14 }}>
            {t('admin.moderationDesc')}
          </p>
        </div>
        <div style={{ minWidth: 260, flex: '0 1 360px' }}>
          <Input
            placeholder={t('admin.searchMessages')}
            value={search}
            onChange={e => {
              setSearch(e.target.value);
              setPage(1);
            }}
            endAdornment={<Icons.Search size={16} stroke="var(--lb-text-muted)" />}
          />
        </div>
      </div>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: '150px minmax(220px, 1fr) minmax(180px, 0.9fr) 130px 110px',
          gap: 12,
          padding: '12px 20px',
          borderBottom: '1px solid var(--lb-line)',
          background: 'var(--lb-panel-soft)',
        }}>
          {[t('admin.sender'), t('admin.message'), t('admin.conversation'), t('admin.date'), t('admin.actions')].map(h => (
            <span key={h} className="lb-eyebrow">{h}</span>
          ))}
        </div>

        {isLoading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}>
            <Spinner />
          </div>
        ) : (data?.data ?? []).length === 0 ? (
          <div style={{ padding: 32, textAlign: 'center', color: 'var(--lb-text-muted)', fontSize: 13 }}>
            {t('admin.noData')}
          </div>
        ) : (
          (data?.data ?? []).map((message, idx) => {
            const isConfirming = confirmDelete === message.messageId;
            const isLast = idx === (data?.data.length ?? 0) - 1;

            return (
              <div
                key={message.messageId}
                style={{
                  display: 'grid',
                  gridTemplateColumns: '150px minmax(220px, 1fr) minmax(180px, 0.9fr) 130px 110px',
                  gap: 12,
                  padding: '14px 20px',
                  borderBottom: isLast ? 'none' : '1px solid var(--lb-line)',
                  alignItems: 'center',
                }}
              >
                <span style={{ fontSize: 14, fontWeight: 650, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {message.sender?.username ?? t('admin.deletedUser')}
                </span>
                <span
                  title={message.content}
                  style={{
                    fontSize: 13,
                    lineHeight: 1.45,
                    color: 'var(--lb-text)',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {message.content}
                </span>
                <span
                  title={conversationLabel(message)}
                  style={{
                    fontSize: 12,
                    color: 'var(--lb-text-muted)',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {conversationLabel(message)}
                </span>
                <span style={{ fontSize: 12, color: 'var(--lb-text-muted)', fontFamily: 'var(--lb-font-mono)' }}>
                  {formatDate(message.createdAt, i18n.language)}
                </span>
                <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-start' }}>
                  {isConfirming ? (
                    <>
                      <button
                        onClick={() => deleteMessage.mutate(message.messageId)}
                        disabled={deleteMessage.isPending}
                        style={{ padding: '4px 8px', borderRadius: 4, background: 'var(--lb-danger)', color: '#fff', border: 'none', fontSize: 11, cursor: 'pointer' }}
                      >
                        {t('admin.yes')}
                      </button>
                      <button
                        onClick={() => setConfirmDelete(null)}
                        disabled={deleteMessage.isPending}
                        style={{ padding: '4px 8px', borderRadius: 4, background: 'var(--lb-panel-soft)', color: 'var(--lb-text-muted)', border: '1px solid var(--lb-line)', fontSize: 11, cursor: 'pointer' }}
                      >
                        {t('admin.no')}
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => setConfirmDelete(message.messageId)}
                      title={t('admin.deleteMessage')}
                      style={{ padding: '6px', borderRadius: 6, background: 'transparent', border: '1px solid var(--lb-line)', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
                    >
                      <Icons.Trash size={14} stroke="var(--lb-danger)" />
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </Card>

      {data && data.total > PAGE_SIZE && (
        <div style={{ display: 'flex', gap: 10, justifyContent: 'center', alignItems: 'center' }}>
          <Button variant="ghost" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>
            {t('common.back')}
          </Button>
          <span style={{ fontSize: 13, color: 'var(--lb-text-muted)' }}>
            {page} / {totalPages}
          </span>
          <Button variant="ghost" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>
            {t('common.next')}
          </Button>
        </div>
      )}
    </div>
  );
}

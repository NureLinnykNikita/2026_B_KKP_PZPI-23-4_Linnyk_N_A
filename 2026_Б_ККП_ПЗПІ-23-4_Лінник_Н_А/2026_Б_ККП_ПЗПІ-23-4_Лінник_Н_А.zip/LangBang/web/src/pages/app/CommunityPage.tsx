import { useEffect, useMemo, useRef, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { chatApi } from '../../api/endpoints';
import { getChatSocket } from '../../api/socket';
import { useAuthStore } from '../../store/auth.store';
import { Card, Button, Spinner, Input, Select } from '../../components/ui';
import { Icons, InitialAvatar } from '../../components/ui/icons';
import type { ChatUser, Conversation, Message } from '../../types';
import { formatDate } from '../../i18n/locale';

function getOtherParticipant(conversation: Conversation, currentUserId?: string) {
  return conversation.participants?.find(p => p.participantId !== currentUserId)?.user ?? null;
}

function getConversationTitle(conversation: Conversation, currentUserId?: string) {
  return getOtherParticipant(conversation, currentUserId)?.username || conversation.title || 'Conversation';
}

export function CommunityPage() {
  const { t, i18n } = useTranslation();
  const { user } = useAuthStore();
  const qc = useQueryClient();
  const [activeConv, setActiveConv] = useState<Conversation | null>(null);
  const [input, setInput] = useState('');
  const [search, setSearch] = useState('');
  const [selectedUserId, setSelectedUserId] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: conversations = [], isLoading: convLoading } = useQuery({
    queryKey: ['conversations'],
    queryFn: () => chatApi.getConversations().then(r => r.data.conversations),
  });

  const { data: searchUsers = [], isLoading: searchLoading } = useQuery({
    queryKey: ['chat-users', search.trim()],
    queryFn: () => chatApi.searchUsers(search.trim()).then(r => r.data.users),
  });

  const { data: messages = [], isLoading: msgLoading } = useQuery({
    queryKey: ['messages', activeConv?.conversationId],
    queryFn: () => chatApi.getMessages(activeConv!.conversationId).then(r => r.data.messages),
    enabled: !!activeConv,
  });

  const sortedConversations = useMemo(
    () => [...conversations].sort((a, b) => {
      const aDate = a.messages?.[0]?.createdAt || a.createdAt;
      const bDate = b.messages?.[0]?.createdAt || b.createdAt;
      return new Date(bDate).getTime() - new Date(aDate).getTime();
    }),
    [conversations]
  );

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeConv?.conversationId]);

  useEffect(() => {
    const socket = getChatSocket();
    if (!socket) return;

    const handleMessageNew = ({ conversationId, message }: { conversationId: string; message: Message }) => {
      qc.setQueryData<Message[]>(['messages', conversationId], (prev = []) => {
        if (prev.some(m => m.messageId === message.messageId)) return prev;
        return [...prev, message];
      });
      qc.invalidateQueries({ queryKey: ['conversations'] });
    };

    const handleConversationUpdated = ({ conversation }: { conversation: Conversation }) => {
      qc.setQueryData<Conversation[]>(['conversations'], (prev = []) => {
        const exists = prev.some(c => c.conversationId === conversation.conversationId);
        return exists
          ? prev.map(c => c.conversationId === conversation.conversationId ? conversation : c)
          : [conversation, ...prev];
      });
      socket.emit('conversation:join', conversation.conversationId);
    };

    socket.on('message:new', handleMessageNew);
    socket.on('conversation:updated', handleConversationUpdated);

    return () => {
      socket.off('message:new', handleMessageNew);
      socket.off('conversation:updated', handleConversationUpdated);
    };
  }, [qc]);

  useEffect(() => {
    if (!activeConv) return;
    const refreshed = conversations.find(c => c.conversationId === activeConv.conversationId);
    if (refreshed) setActiveConv(refreshed);
  }, [activeConv, conversations]);

  const createDirectMutation = useMutation({
    mutationFn: (participantId: string) => chatApi.createDirectConversation(participantId),
    onSuccess: (res) => {
      setActiveConv(res.data.conversation);
      setSearch('');
      setSelectedUserId('');
      qc.invalidateQueries({ queryKey: ['conversations'] });
      getChatSocket()?.emit('conversation:join', res.data.conversation.conversationId);
    },
  });

  const sendMutation = useMutation({
    mutationFn: (content: string) => chatApi.sendMessage(activeConv!.conversationId, content),
    onSuccess: (res) => {
      if (!activeConv) return;
      qc.setQueryData<Message[]>(['messages', activeConv.conversationId], (prev = []) => {
        if (prev.some(m => m.messageId === res.data.sentMessage.messageId)) return prev;
        return [...prev, res.data.sentMessage];
      });
      qc.invalidateQueries({ queryKey: ['conversations'] });
      setInput('');
    },
  });

  const handleSend = () => {
    if (!input.trim() || !activeConv) return;
    sendMutation.mutate(input.trim());
  };

  const handleSelectUser = (userId: string) => {
    setSelectedUserId(userId);
    if (userId) {
      createDirectMutation.mutate(userId);
    }
  };

  const renderConversation = (conversation: Conversation) => {
    const other = getOtherParticipant(conversation, user?.userId);
    const lastMessage = conversation.messages?.[0];
    const isActive = activeConv?.conversationId === conversation.conversationId;

    return (
      <button
        key={conversation.conversationId}
        onClick={() => setActiveConv(conversation)}
        style={{
          width: '100%',
          padding: '10px 12px',
          borderRadius: 'var(--lb-radius-sm)',
          background: isActive ? 'var(--lb-panel-soft)' : 'transparent',
          border: `1px solid ${isActive ? 'var(--lb-accent)' : 'var(--lb-line)'}`,
          color: 'var(--lb-text)',
          cursor: 'pointer',
          textAlign: 'left',
          display: 'flex',
          gap: 10,
          alignItems: 'center',
        }}
      >
        <InitialAvatar name={other?.username} size={30} />
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {getConversationTitle(conversation, user?.userId)}
          </div>
          <div style={{ fontSize: 11, color: 'var(--lb-text-muted)', marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {lastMessage?.content || t('community.noMessages')}
          </div>
        </div>
      </button>
    );
  };

  const renderSearchUser = (chatUser: ChatUser) => (
    <button
      key={chatUser.userId}
      onClick={() => createDirectMutation.mutate(chatUser.userId)}
      disabled={createDirectMutation.isPending}
      style={{
        width: '100%',
        padding: '10px 12px',
        borderRadius: 'var(--lb-radius-sm)',
        background: 'var(--lb-panel-soft)',
        border: '1px solid var(--lb-line)',
        color: 'var(--lb-text)',
        cursor: 'pointer',
        textAlign: 'left',
        display: 'flex',
        gap: 10,
        alignItems: 'center',
      }}
    >
      <InitialAvatar name={chatUser.username} size={28} />
      <span style={{ fontSize: 13, fontWeight: 600 }}>{chatUser.username}</span>
    </button>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--lb-section-gap)', maxWidth: 980, animation: 'fadeIn 0.2s ease' }}>
      <header>
        <h1 className="lb-h1">{t('community.title')}</h1>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr', gap: 'var(--lb-section-gap)', height: 640 }}>
        <Card style={{ display: 'flex', flexDirection: 'column', gap: 14, padding: 16, minHeight: 0 }}>
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={t('community.searchUsers')}
          />
          <Select
            label={t('community.availableUsers')}
            value={selectedUserId}
            onChange={e => handleSelectUser(e.target.value)}
            disabled={searchLoading || createDirectMutation.isPending || searchUsers.length === 0}
            options={[
              { value: '', label: searchUsers.length > 0 ? t('community.selectUser') : t('community.noUsersFound') },
              ...searchUsers.map(chatUser => ({ value: chatUser.userId, label: chatUser.username })),
            ]}
          />

          {search.trim().length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, minHeight: 0, overflowY: 'auto' }}>
              <div className="lb-eyebrow">{t('community.searchResults')}</div>
              {searchLoading ? <Spinner /> : searchUsers.length > 0 ? searchUsers.map(renderSearchUser) : (
                <div style={{ fontSize: 13, color: 'var(--lb-text-muted)', padding: '8px 0' }}>{t('community.noUsersFound')}</div>
              )}
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, minHeight: 0, overflowY: 'auto' }}>
              <div className="lb-eyebrow">{t('community.conversations')}</div>
              {convLoading ? <Spinner /> : sortedConversations.length > 0 ? sortedConversations.map(renderConversation) : (
                <div style={{ fontSize: 13, color: 'var(--lb-text-muted)', padding: '8px 0' }}>
                  {t('community.noConversations')}
                </div>
              )}
            </div>
          )}
        </Card>

        <Card style={{ display: 'flex', flexDirection: 'column', padding: 0, overflow: 'hidden' }}>
          {!activeConv ? (
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, color: 'var(--lb-text-muted)', textAlign: 'center', padding: 24 }}>
              <Icons.Chat size={48} stroke="var(--lb-text-muted)" />
              <p style={{ fontSize: 14, margin: 0 }}>{t('community.startConversation')}</p>
            </div>
          ) : (
            <>
              <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--lb-line)', display: 'flex', alignItems: 'center', gap: 10 }}>
                <InitialAvatar name={getConversationTitle(activeConv, user?.userId)} size={32} />
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>{getConversationTitle(activeConv, user?.userId)}</div>
                  <div style={{ fontSize: 11, color: 'var(--lb-text-muted)' }}>
                    {formatDate(activeConv.createdAt, i18n.language, { day: 'numeric', month: 'short' })}
                  </div>
                </div>
              </div>

              <div style={{ flex: 1, overflowY: 'auto', padding: '20px 20px 0' }}>
                {msgLoading ? (
                  <div style={{ display: 'flex', justifyContent: 'center', padding: 32 }}><Spinner /></div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    {messages.map(msg => {
                      const isMe = msg.senderId === user?.userId;
                      return (
                        <div key={msg.messageId} style={{ display: 'flex', gap: 10, justifyContent: isMe ? 'flex-end' : 'flex-start', alignItems: 'flex-end' }}>
                          {!isMe && (
                            <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--lb-panel-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                              <InitialAvatar name={msg.sender?.username} size={28} />
                            </div>
                          )}
                          <div style={{ maxWidth: '70%', padding: '10px 14px', borderRadius: 12, background: isMe ? 'var(--lb-accent)' : 'var(--lb-panel-soft)', color: isMe ? 'var(--lb-accent-ink)' : 'var(--lb-text)', fontSize: 14, lineHeight: 1.5 }}>
                            {msg.content}
                          </div>
                        </div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </div>

              <div style={{ padding: '16px 20px', borderTop: '1px solid var(--lb-line)', display: 'flex', gap: 10 }}>
                <input
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
                  placeholder={t('community.typeMessage')}
                  style={{ flex: 1, background: 'var(--lb-panel-soft)', border: '1px solid var(--lb-line)', borderRadius: 'var(--lb-radius-sm)', color: 'var(--lb-text)', fontFamily: 'var(--lb-font-sans)', fontSize: 14, padding: '10px 14px', outline: 'none' }}
                />
                <Button onClick={handleSend} disabled={!input.trim() || sendMutation.isPending}>
                  <Icons.Send size={16} />
                  {t('community.send')}
                </Button>
              </div>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}

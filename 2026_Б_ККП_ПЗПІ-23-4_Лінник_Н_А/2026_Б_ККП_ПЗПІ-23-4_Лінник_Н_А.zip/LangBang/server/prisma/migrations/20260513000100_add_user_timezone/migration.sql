-- AlterTable
ALTER TABLE "users" ADD COLUMN "timezone" VARCHAR(50) NOT NULL DEFAULT 'Europe/Kyiv';

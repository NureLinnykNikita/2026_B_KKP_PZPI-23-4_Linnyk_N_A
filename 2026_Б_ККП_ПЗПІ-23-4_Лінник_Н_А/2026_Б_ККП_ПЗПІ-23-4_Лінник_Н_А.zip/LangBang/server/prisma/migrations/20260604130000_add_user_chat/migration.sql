ALTER TABLE "users"
ADD COLUMN "is_chat_searchable" BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE "conversations"
ADD COLUMN "direct_key" TEXT;

CREATE UNIQUE INDEX "conversations_direct_key_key" ON "conversations"("direct_key");

import {PERMISSIONS_DATA} from "./permissionsData";
import {ROLE_PERMISSIONS} from "../../src/constants/roles";
import {prisma} from "../../src/lib/prisma";
import {
    CourseLevel,
    ExerciseType,
    UserRole
} from "../../generated/prisma/enums";
import {hashPassword} from "../../src/utils/password";
import {ACHIEVEMENTS_DATA} from "./achievementsData";

async function seedRoles() {
    await prisma.permission.createMany({
        data: PERMISSIONS_DATA,
        skipDuplicates: true
    })

    const dbPermissions = await prisma.permission.findMany();
    const permissionMap = new Map(dbPermissions.map(p => [p.code, p.id]));

    for (const [role, permissions] of Object.entries(ROLE_PERMISSIONS)) {
        for (const permission of permissions) {
            const permissionId = permissionMap.get(permission);

            if (!permissionId) {
                throw new Error(`Permission not found in seed data: ${permission}`);
            }

            await prisma.rolePermission.upsert({
                where: {
                    role_permissionId: {
                        role: role as UserRole,
                        permissionId
                    }
                },
                update: {},
                create: {
                    role: role as UserRole,
                    permissionId
                }
            })
        }
    }
}

async function seedAdmin() {
    await prisma.user.upsert({
        where: {email: "admin@langbang.com"},
        update: { role: UserRole.admin, tokenVersion: { increment: 1 } },
        create: {
            username: "admin",
            email: "admin@langbang.com",
            passwordHash: await hashPassword('admin123'),
            role: UserRole.admin
        }
    })
}

async function seedLanguages() {
    const languages = [
        { code: 'en', name: 'English' },
        { code: 'uk', name: 'Ukrainian' },
        { code: 'de', name: 'German' },
        { code: 'fr', name: 'French' },
        { code: 'es', name: 'Spanish' },
        { code: 'pl', name: 'Polish' },
    ];
    for (const lang of languages) {
        await prisma.language.upsert({
            where: { code: lang.code },
            update: {},
            create: lang,
        });
        console.log(`Language upserted: ${lang.name}`);
    }
}

type ExerciseSeed = {
    type: ExerciseType;
    question: string;
    correctAnswer: string;
    points: number;
    options: string[];
    hint?: string;
};

type LessonSeed = {
    title: string;
    description: string;
    exercises: ExerciseSeed[];
};

type CourseSeed = {
    title: string;
    description: string;
    level: CourseLevel;
    lessons: LessonSeed[];
};

const COURSE_SEEDS: CourseSeed[] = [
    {
        title: 'English Starter',
        description: 'A practical first course with greetings, classroom phrases, numbers, and everyday objects.',
        level: CourseLevel.A1,
        lessons: [
            {
                title: 'Greetings & Introductions',
                description: 'Say hello, introduce yourself, and ask simple personal questions.',
                exercises: [
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "Good morning"',
                        correctAnswer: 'Доброго ранку',
                        points: 10,
                        options: ['Доброго ранку', 'Доброї ночі', 'До побачення', 'Будь ласка'],
                    },
                    {
                        type: ExerciseType.writing,
                        question: 'Fill in the gap: "My ___ is Anna."',
                        correctAnswer: 'name',
                        points: 15,
                        options: ['name', 'city', 'book', 'teacher'],
                        hint: 'The word you use when introducing yourself',
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Write in English: "Приємно познайомитися"',
                        correctAnswer: 'Nice to meet you',
                        points: 15,
                        options: ['Nice to meet you', 'See you later', 'How old are you', 'I am from Kyiv'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "Where are you from?"',
                        correctAnswer: 'Звідки ти?',
                        points: 15,
                        options: ['Звідки ти?', 'Як тебе звати?', 'Скільки тобі років?', 'Де моя книга?'],
                    },
                ],
            },
            {
                title: 'Classroom English',
                description: 'Understand basic instructions and useful classroom phrases.',
                exercises: [
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "Open your book"',
                        correctAnswer: 'Відкрий книгу',
                        points: 10,
                        options: ['Відкрий книгу', 'Закрий двері', 'Напиши відповідь', 'Послухай вчителя'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Write in English: "Повтори, будь ласка"',
                        correctAnswer: 'Repeat, please',
                        points: 15,
                        options: ['Repeat, please', 'Read the text', 'Close the window', 'Stand up'],
                    },
                    {
                        type: ExerciseType.writing,
                        question: 'Fill in the gap: "I don\'t ___."',
                        correctAnswer: 'understand',
                        points: 15,
                        options: ['understand', 'breakfast', 'expensive', 'tomorrow'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "Listen and repeat"',
                        correctAnswer: 'Слухай і повторюй',
                        points: 15,
                        options: ['Слухай і повторюй', 'Читай і пиши', 'Встань і йди', 'Запитай і відповідай'],
                    },
                ],
            },
            {
                title: 'Numbers & Age',
                description: 'Count from one to twenty and talk about age.',
                exercises: [
                    {
                        type: ExerciseType.translation,
                        question: 'Write in English: "Дванадцять"',
                        correctAnswer: 'Twelve',
                        points: 10,
                        options: ['Twelve', 'Twenty', 'Two', 'Ten'],
                    },
                    {
                        type: ExerciseType.writing,
                        question: 'Fill in the gap: "One, two, three, ___, five."',
                        correctAnswer: 'four',
                        points: 10,
                        options: ['four', 'six', 'eight', 'nine'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "I am eighteen years old"',
                        correctAnswer: 'Мені вісімнадцять років',
                        points: 15,
                        options: ['Мені вісімнадцять років', 'Мені вісім років', 'Я маю вісімнадцять книжок', 'Я живу вісімнадцять днів'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Write in English: "Скільки тобі років?"',
                        correctAnswer: 'How old are you?',
                        points: 15,
                        options: ['How old are you?', 'Where are you from?', 'What is your name?', 'How much is it?'],
                    },
                ],
            },
        ],
    },
    {
        title: 'Everyday English',
        description: 'Build everyday English for shopping, directions, routines, and restaurants.',
        level: CourseLevel.A2,
        lessons: [
            {
                title: 'Shopping & Prices',
                description: 'Ask about prices, sizes, payments, and discounts.',
                exercises: [
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "How much does it cost?"',
                        correctAnswer: 'Скільки це коштує?',
                        points: 10,
                        options: ['Скільки це коштує?', 'Де знаходиться магазин?', 'Який у вас розмір?', 'Можна мені меню?'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Write in English: "Знижка"',
                        correctAnswer: 'Discount',
                        points: 10,
                        options: ['Discount', 'Receipt', 'Size', 'Change'],
                    },
                    {
                        type: ExerciseType.writing,
                        question: 'Fill in the gap: "Can I pay by ___?"',
                        correctAnswer: 'card',
                        points: 15,
                        options: ['card', 'cashier', 'price', 'bag'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "I need a smaller size"',
                        correctAnswer: 'Мені потрібен менший розмір',
                        points: 15,
                        options: ['Мені потрібен менший розмір', 'Мені потрібна вища ціна', 'Мені потрібен інший магазин', 'Мені потрібна нова квитанція'],
                    },
                ],
            },
            {
                title: 'Travel & Directions',
                description: 'Ask for directions and understand travel instructions.',
                exercises: [
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "Turn left at the traffic lights."',
                        correctAnswer: 'Поверніть ліворуч на світлофорі.',
                        points: 15,
                        options: ['Поверніть ліворуч на світлофорі.', 'Ідіть прямо до вокзалу.', 'Поверніть праворуч біля банку.', 'Зупиніться перед мостом.'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Write in English: "Аеропорт"',
                        correctAnswer: 'Airport',
                        points: 10,
                        options: ['Airport', 'Bus stop', 'Train station', 'Hotel'],
                    },
                    {
                        type: ExerciseType.writing,
                        question: 'Fill in the gap: "Go ___ for two blocks."',
                        correctAnswer: 'straight',
                        points: 15,
                        options: ['straight', 'left', 'ticket', 'near'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "The train station is behind the hotel."',
                        correctAnswer: 'Залізничний вокзал за готелем.',
                        points: 15,
                        options: ['Залізничний вокзал за готелем.', 'Автобусна зупинка перед готелем.', 'Аеропорт біля вокзалу.', 'Міст праворуч від готелю.'],
                    },
                ],
            },
            {
                title: 'Food & Restaurants',
                description: 'Order food, ask for recommendations, and pay the bill.',
                exercises: [
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "Could I have the menu, please?"',
                        correctAnswer: 'Можна мені меню, будь ласка?',
                        points: 15,
                        options: ['Можна мені меню, будь ласка?', 'Можна мені квиток, будь ласка?', 'Можна мені рахунок завтра?', 'Можна мені номер кімнати?'],
                    },
                    {
                        type: ExerciseType.writing,
                        question: 'Fill in the gap: "I\'m ___. What do you recommend?"',
                        correctAnswer: 'hungry',
                        points: 15,
                        options: ['hungry', 'late', 'cheap', 'open'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Write in English: "Рахунок"',
                        correctAnswer: 'Bill',
                        points: 10,
                        options: ['Bill', 'Soup', 'Fork', 'Waiter'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "I would like chicken with rice."',
                        correctAnswer: 'Я хотів би курку з рисом.',
                        points: 15,
                        options: ['Я хотів би курку з рисом.', 'Я хотів би чай з лимоном.', 'Я хотів би салат без солі.', 'Я хотів би суп дня.'],
                    },
                ],
            },
        ],
    },
    {
        title: 'English in Context',
        description: 'Practice intermediate English for work, health, technology, and the environment.',
        level: CourseLevel.B1,
        lessons: [
            {
                title: 'Work & Career',
                description: 'Talk about jobs, interviews, colleagues, and responsibilities.',
                exercises: [
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "I applied for a job last week."',
                        correctAnswer: 'Я подав заявку на роботу минулого тижня.',
                        points: 20,
                        options: ['Я подав заявку на роботу минулого тижня.', 'Я звільнився з роботи минулого тижня.', 'Я отримав підвищення минулого тижня.', 'Я працював з дому минулого тижня.'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Write in English: "Співбесіда"',
                        correctAnswer: 'Job interview',
                        points: 15,
                        options: ['Job interview', 'Work schedule', 'Salary rise', 'Team meeting'],
                    },
                    {
                        type: ExerciseType.writing,
                        question: 'Fill in the gap: "He received a pay ___ after three years."',
                        correctAnswer: 'rise',
                        points: 20,
                        options: ['rise', 'desk', 'task', 'shift'],
                        hint: 'A salary increase',
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "My colleague is responsible for customer support."',
                        correctAnswer: 'Мій колега відповідає за підтримку клієнтів.',
                        points: 20,
                        options: ['Мій колега відповідає за підтримку клієнтів.', 'Мій керівник шукає нову роботу.', 'Мій клієнт проводить співбесіду.', 'Мій офіс відкривається о девʼятій.'],
                    },
                ],
            },
            {
                title: 'Health & Lifestyle',
                description: 'Discuss symptoms, doctor visits, habits, and healthy choices.',
                exercises: [
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "You should see a doctor immediately."',
                        correctAnswer: 'Вам слід негайно звернутися до лікаря.',
                        points: 20,
                        options: ['Вам слід негайно звернутися до лікаря.', 'Вам слід купити рецепт завтра.', 'Вам слід уникати здорової їжі.', 'Вам слід пропустити прийом ліків.'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Write in English: "Симптоми"',
                        correctAnswer: 'Symptoms',
                        points: 15,
                        options: ['Symptoms', 'Prescription', 'Exercise', 'Appointment'],
                    },
                    {
                        type: ExerciseType.writing,
                        question: 'Fill in the gap: "A balanced ___ is important for good health."',
                        correctAnswer: 'diet',
                        points: 20,
                        options: ['diet', 'fever', 'clinic', 'pain'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "Regular exercise helps reduce stress."',
                        correctAnswer: 'Регулярні фізичні вправи допомагають зменшити стрес.',
                        points: 20,
                        options: ['Регулярні фізичні вправи допомагають зменшити стрес.', 'Регулярний сон викликає сильний стрес.', 'Збалансована дієта збільшує температуру.', 'Рецепт допомагає записатися на прийом.'],
                    },
                ],
            },
            {
                title: 'Technology & Society',
                description: 'Use vocabulary for apps, updates, security, and online communication.',
                exercises: [
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "This app uses artificial intelligence."',
                        correctAnswer: 'Цей додаток використовує штучний інтелект.',
                        points: 20,
                        options: ['Цей додаток використовує штучний інтелект.', 'Цей сайт продає компʼютерні ігри.', 'Цей телефон має слабку батарею.', 'Цей пароль потрібно змінити.'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Write in English: "Хмарне сховище"',
                        correctAnswer: 'Cloud storage',
                        points: 15,
                        options: ['Cloud storage', 'Software update', 'Social media', 'Search engine'],
                    },
                    {
                        type: ExerciseType.writing,
                        question: 'Fill in the gap: "Please ___ your password regularly for security."',
                        correctAnswer: 'change',
                        points: 20,
                        options: ['change', 'download', 'follow', 'charge'],
                    },
                    {
                        type: ExerciseType.translation,
                        question: 'Translate into Ukrainian: "Social media has changed how people communicate."',
                        correctAnswer: 'Соціальні мережі змінили те, як люди спілкуються.',
                        points: 20,
                        options: ['Соціальні мережі змінили те, як люди спілкуються.', 'Хмарне сховище видалило всі повідомлення.', 'Оновлення програми зламало інтернет.', 'Штучний інтелект вимкнув телефон.'],
                    },
                ],
            },
        ],
    },
];

const LEGACY_COURSE_TITLES = [
    'English for Beginners',
    'English for Elementary',
];

function exerciseData(exercise: ExerciseSeed, sequence: number) {
    return {
        sequence,
        type: exercise.type,
        question: exercise.question,
        correctAnswer: exercise.correctAnswer,
        points: exercise.points,
        metadata: {
            options: exercise.options,
            ...(exercise.hint ? { hint: exercise.hint } : {}),
        },
    };
}

async function seedCoursesAndLessonsAndExercises() {
    const english = await prisma.language.upsert({
        where: { code: 'en' },
        update: {},
        create: { code: 'en', name: 'English' },
    });

    const courseTitles = [
        ...COURSE_SEEDS.map(course => course.title),
        ...LEGACY_COURSE_TITLES,
    ];
    await prisma.course.deleteMany({
        where: {
            targetLanguageId: english.id,
            title: { in: courseTitles },
        },
    });

    for (const course of COURSE_SEEDS) {
        const createdCourse = await prisma.course.create({
            data: {
                title: course.title,
                description: course.description,
                level: course.level,
                targetLanguageId: english.id,
                lessons: {
                    create: course.lessons.map((lesson, lessonIndex) => ({
                        title: lesson.title,
                        description: lesson.description,
                        sequence: lessonIndex + 1,
                        exercises: {
                            create: lesson.exercises.map((exercise, exerciseIndex) =>
                                exerciseData(exercise, exerciseIndex + 1)
                            ),
                        },
                    })),
                },
            },
        });

        console.log(`Course seeded: ${createdCourse.title}`);
    }
}

async function seedAchievements() {
    await prisma.achievement.createMany({
        data: ACHIEVEMENTS_DATA,
        skipDuplicates: true
    })
}

async function main() {
    await seedRoles();
    await seedAdmin();
    await seedAchievements();
    await seedLanguages();
    await seedCoursesAndLessonsAndExercises();
}

main()
    .then(async () => {
        console.log('Seeding done.');
        await prisma.$disconnect();
    })
    .catch(async (e) => {
        console.error(e);
        await prisma.$disconnect();
        process.exit(1);
    })

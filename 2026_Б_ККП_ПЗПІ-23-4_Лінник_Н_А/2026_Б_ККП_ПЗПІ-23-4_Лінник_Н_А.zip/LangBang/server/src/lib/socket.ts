import {Server} from 'socket.io';
import type {Server as HttpServer} from 'http';
import jwt from 'jsonwebtoken';
import {ENV} from '../config/env.js';
import {prisma} from './prisma.js';
import type {CustomJwtPayload} from '../types/express.js';

let io: Server | null = null;

const conversationRoom = (conversationId: string) => `conversation:${conversationId}`;
const userRoom = (userId: string) => `user:${userId}`;

export function initSocket(httpServer: HttpServer, allowedOrigins: string[]) {
    io = new Server(httpServer, {
        cors: {
            origin: allowedOrigins,
            credentials: true,
        },
    });

    io.use(async (socket, next) => {
        try {
            const token = socket.handshake.auth?.token;

            if (!token || typeof token !== 'string') {
                throw new Error('Socket auth token is required');
            }

            const decoded = jwt.verify(token, ENV.JWT_ACCESS_SECRET) as CustomJwtPayload;
            const user = await prisma.user.findUnique({
                where: {userId: decoded.userId},
                select: {userId: true, tokenVersion: true},
            });

            if (!user || user.tokenVersion !== decoded.tokenVersion) {
                throw new Error('Socket auth token is invalid');
            }

            socket.data.userId = user.userId;
            next();
        } catch (error) {
            next(error instanceof Error ? error : new Error('Socket auth failed'));
        }
    });

    io.on('connection', async (socket) => {
        const userId = socket.data.userId as string;
        socket.join(userRoom(userId));

        const conversations = await prisma.conversationParticipant.findMany({
            where: {
                participantId: userId,
                participantType: 'user',
            },
            select: {conversationId: true},
        });

        conversations.forEach(({conversationId}) => {
            socket.join(conversationRoom(conversationId));
        });

        socket.on('conversation:join', async (conversationId: string) => {
            const participant = await prisma.conversationParticipant.findUnique({
                where: {
                    conversationId_participantId_participantType: {
                        conversationId,
                        participantId: userId,
                        participantType: 'user',
                    },
                },
            });

            if (participant) {
                socket.join(conversationRoom(conversationId));
            }
        });
    });

    return io;
}

export function emitMessageNew(conversationId: string, message: unknown) {
    io?.to(conversationRoom(conversationId)).emit('message:new', {
        conversationId,
        message,
    });
}

export function emitConversationUpdated(conversation: {
    conversationId: string;
    participants: {participantId: string}[];
}) {
    conversation.participants.forEach(({participantId}) => {
        io?.to(userRoom(participantId)).emit('conversation:updated', {
            conversation,
        });
    });
}

import { Router } from 'express';
import {
    createDirectConversation,
    deleteMessage,
    getMessages,
    listConversations,
    searchUsers,
    sendMessage
} from "../controllers/chat.controller.js";
import {authenticateToken} from "../middlewares/auth.middleware.js";
import {requirePermission} from "../middlewares/permission.middleware.js";

const router = Router();

router.get('/chat/users', authenticateToken, searchUsers);

router.get('/conversations', authenticateToken, listConversations);

router.post('/conversations/direct', authenticateToken, createDirectConversation);

router.post('/conversations/:conversationId/messages', authenticateToken, sendMessage);

router.get('/conversations/:conversationId/messages', authenticateToken, getMessages);

router.delete('/conversations/:conversationId/messages/:messageId', authenticateToken,
    requirePermission('moderate_chat'), deleteMessage);

export default router;

import { Router } from 'express';
import {
  deleteModerationMessage,
  exportData,
  getAdminStats,
  getAdminUsers,
  getModerationMessages,
  importData,
} from '../controllers/admin.controller.js';
import { authenticateToken } from '../middlewares/auth.middleware.js';
import { requirePermission } from '../middlewares/permission.middleware.js';

const router = Router();

router.get('/admin/users', authenticateToken, requirePermission('manage_user'), getAdminUsers);
router.get('/admin/stats', authenticateToken, requirePermission('manage_user'), getAdminStats);
router.get('/admin/export', authenticateToken, requirePermission('manage_user'), exportData);
router.post('/admin/import', authenticateToken, requirePermission('manage_user'), importData);
router.get('/admin/moderation/messages', authenticateToken, requirePermission('moderate_chat'), getModerationMessages);
router.delete('/admin/moderation/messages/:messageId', authenticateToken, requirePermission('moderate_chat'), deleteModerationMessage);

export default router;

import {Request, Response, NextFunction} from "express";
import * as chatService from "../services/chat.service.js";

export const searchUsers = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {
        const users = await chatService.searchUsers(
            req.user!.userId,
            typeof req.query.search === 'string' ? req.query.search : ''
        );

        res.status(200).json({users});
    } catch (err) {
        next(err);
    }
};

export const listConversations = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {
        const conversations = await chatService.listConversations(req.user!.userId);
        res.status(200).json({conversations});
    } catch (err) {
        next(err);
    }
};

export const createDirectConversation = async (
    req: Request<{}, {}, {participantId: string}>,
    res: Response,
    next: NextFunction
) => {
    try {
        const conversation = await chatService.createOrGetDirectConversation(
            req.user!.userId,
            req.body.participantId
        );

        res.status(201).json({conversation});
    } catch (err) {
        next(err);
    }
};

export const sendMessage = async (
    req: Request<{conversationId: string}, {}, {content: string}>,
    res: Response,
    next: NextFunction
) => {
    try {
        const message = await chatService.sendMessage(
            req.params.conversationId,
            req.user!.userId,
            req.body.content
        );

        res.status(201).json({
            message: "Message sent successfully",
            sentMessage: message,
        });
    } catch (err) {
        next(err);
    }
};

export const getMessages = async (
    req: Request<{conversationId: string}>,
    res: Response,
    next: NextFunction
) => {
    try {
        const messages = await chatService.getMessages(
            req.params.conversationId,
            req.user!.userId
        );

        res.status(200).json({messages});
    } catch (err) {
        next(err);
    }
};

export const deleteMessage = async (
    req: Request<{ conversationId: string, messageId: string }>,
    res: Response,
    next: NextFunction
) => {
    try {
        const { conversationId, messageId } = req.params;
        const deletedMessage = await chatService.deleteMessage(conversationId, messageId);

        res.status(200).json({
            message: "Message deleted successfully",
            deletedMessage
        });
    } catch (err) {
        next(err);
    }
};

import {Prisma} from "../../generated/prisma/client.js";
import {prisma} from "../lib/prisma.js";
import {emitConversationUpdated, emitMessageNew} from "../lib/socket.js";

const userPreviewSelect = {
    userId: true,
    username: true,
    avatarUrl: true,
} satisfies Prisma.UserSelect;

const conversationInclude = {
    participants: {
        include: {
            user: {
                select: userPreviewSelect,
            },
        },
    },
    messages: {
        orderBy: {createdAt: 'desc' as const},
        take: 1,
        include: {
            sender: {
                select: userPreviewSelect,
            },
        },
    },
};

function directKeyFor(userA: string, userB: string) {
    return [userA, userB].sort().join(':');
}

async function assertParticipant(conversationId: string, userId: string) {
    const participant = await prisma.conversationParticipant.findUnique({
        where: {
            conversationId_participantId_participantType: {
                conversationId,
                participantId: userId,
                participantType: 'user',
            },
        },
    });

    if (!participant) {
        throw new Error('Conversation not found');
    }
}

export async function searchUsers(currentUserId: string, search = '') {
    const trimmed = search.trim();

    return prisma.user.findMany({
        where: {
            userId: {not: currentUserId},
            isChatSearchable: true,
            ...(trimmed
                ? {
                    username: {
                        contains: trimmed,
                        mode: 'insensitive' as const,
                    },
                }
                : {}),
        },
        select: userPreviewSelect,
        orderBy: {username: 'asc'},
        take: trimmed ? 20 : 50,
    });
}

export async function listConversations(userId: string) {
    return prisma.conversation.findMany({
        where: {
            participants: {
                some: {
                    participantId: userId,
                    participantType: 'user',
                },
            },
        },
        include: conversationInclude,
        orderBy: {createdAt: 'desc'},
    });
}

export async function createOrGetDirectConversation(currentUserId: string, participantId: string) {
    if (currentUserId === participantId) {
        throw new Error('You cannot start a conversation with yourself');
    }

    const target = await prisma.user.findFirst({
        where: {
            userId: participantId,
            isChatSearchable: true,
        },
        select: {userId: true, username: true},
    });

    if (!target) {
        throw new Error('User not found');
    }

    const directKey = directKeyFor(currentUserId, participantId);

    return prisma.conversation.upsert({
        where: {directKey},
        update: {},
        create: {
            title: null,
            isGroup: false,
            directKey,
            participants: {
                create: [
                    {participantId: currentUserId, participantType: 'user'},
                    {participantId, participantType: 'user'},
                ],
            },
        },
        include: conversationInclude,
    });
}

export async function getMessages(conversationId: string, userId: string) {
    await assertParticipant(conversationId, userId);

    return prisma.message.findMany({
        where: {conversationId},
        orderBy: {createdAt: 'asc'},
        include: {
            sender: {
                select: userPreviewSelect,
            },
        },
    });
}

export async function sendMessage(conversationId: string, userId: string, content: string) {
    const trimmed = content.trim();

    if (!trimmed) {
        throw new Error('Message content is required');
    }

    await assertParticipant(conversationId, userId);

    const message = await prisma.message.create({
        data: {
            conversationId,
            senderId: userId,
            content: trimmed,
            senderType: 'user',
        },
        include: {
            sender: {
                select: userPreviewSelect,
            },
        },
    });

    const conversation = await prisma.conversation.findUnique({
        where: {conversationId},
        include: conversationInclude,
    });

    emitMessageNew(conversationId, message);
    if (conversation) {
        emitConversationUpdated(conversation);
    }

    return message;
}

export const deleteMessage = async (conversationId: string, messageId: string) => {
    const message = await prisma.message.findFirst({
        where: {messageId, conversationId},
    });

    if (!message) {
        throw new Error('Message not found');
    }

    return prisma.message.delete({where: {messageId}});
};
